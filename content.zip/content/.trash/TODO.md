#Important
## wiki
upscale couturier et taverne

## bot
enregistrer les noms/pseudos
commande |wiki
fix username bonjour

## serveur
mettre les descriptions des lieux avec le lien du wiki

