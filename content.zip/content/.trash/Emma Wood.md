#Personnage 

## Image
![[Personnage.EmmaWood.png]]

## Informations
**Nom**: Wood 
**Prénom**: Emma 

**Intimité**:
| **Genre Biologique**: Femme
| **Genre Moral** : Femme 
| **Orientation Sexuelle**: Hétéro
| **Situation**: Célibataire

**Fonction**: jardinière référente du [[Jardin 2]]

## portrait
Emma est une femme plutôt passionnée, elle aime apprendre, elle aime explorer les environs, elle est gentille, généreuse et loyale.

## Histoire
Emma, âgée de 19 ans, parcouru la région pour explorer les environs qui l'entoure. Un jour, Emma est venue dans le royaume après l'avoir trouvé. Une fois qu'elle a pu parler au roi, elle avait conclut un marché avec lui, s'occuper d'un grand terrain du royaume pour en faire un jardin, le [[Jardin 2]], en échange d'argent, d'une maison et de nourriture.