---
draft: true
tags:
- Old
---

## intro

wiki a destination du serveur discord de role play texuel [Fiore Kingdom](https://discord.gg/KUHdKSgEE2)

le role play prend place dans le royaume de [[Fiore]]

## Règles

voici la liste des règles établies pour le bon déroulement du role play dans ce serveur discord

1- [[Règlement]]
2- [[Inactivité]]

## tutoriels

ici vous trouverez quelques tutoriels a destination des roleplayers, afin d'apprendre comment se servir des outils

1- [[Roleplay]]
2- [[Le robot Tupperbox]]

## wiki roleplay

et pour finir, nous avons ici toutes les données des personnages et autres disponibles dans le royaume :D

1- [[Recensement]]
2- [[Magasins]]
3- [[Relations exterieures]]