---
draft: true
tags:
- Old
---

## image
![[PERSONNAGE_ShiaoYue.jpg]]

## Informations
**Nom** : Yue 
**Prénom** : Shiao 

**Intimité**:
| **Genre Biologique**: Femme
| **Genre Moral** : Femme
| **Orientation Sexuelle**: Hétéro
| **Situation**: Célibataire

**Fonction**: Épicière

## portrait
Shiao est une jeune brune aux trait très fin sur le visage, elle a des hauts et des bas mais elle s'efforce toujours de sourire aux clients, puis dans les petits royaumes tout le monde est ami donc elle a surtout tendance a être heureuse au quotidien

## Histoire
Shiao, et sa soeur [Seshai](Seshai%20Yue.md) sont soeur jumelles, lorsqu'elles étaient petites, elles adoraient jouer au magasin, Shiao aimait vendre de tout, elle cherchait dans toute la maison des choses a "vendre" pour les mettre dans son magasin, tandis que [sa soeur](Seshai%20Yue.md), elle, préfèrait autre chose.

Elles vécurent plutôt correctement, elles n'étaient par riches mais elles n'étaient pas non plus dans le besoin. Leurs parents, essayaient des les protéger de leur royaume devenu vraiment toxique, et limite dangereux, entre les émeutes, le jugement d'autrui etc, le royaume était devenu invivable. en grandissant, les deux jumelles commençaient de plus en plus a s'en rendre compte et n'avaient qu'une envie c'était de partir. Cependant, leurs parents avaient encore plus peur de partir, peur de l'inconnu, peur de quitter ce qu'ils connaissaient. C'est alors que, lors de la mort de leurs parents a cause d'une émeute dans le magasin, les deux jumelles, surtout [Shiao](Shiao%20Yue.md) qui était beaucoup plus mature que sa soeur, prit les choses en main et fit tout ce qu'elle pu pour les faire partir.

le soir de leur départ, a l'entrée du royaume, elles virent une scène horrible, elles se précipitèrent toutes les deux vers l'homme au sol, incapable de se relever et abandonné ici par ses ravisseurs. Après une courte discussion, elles aidèrent [Jarvin](Jarvin%20Wells.md), leur nouvel ami, a monter avec elles dans le carrosse. Après plusieurs mois de recherche, les deux soeurs et l'homme arrivèrent dans notre royaume, c'est alors que, comme dans le temps, Shiao ouvrit un magasin d'épices et autres outils. on pouvait trouver de tout dans son magasin !