---
draft: true
tags:
- Old
---

## Image
![[PERSONNAGE_LucyAstaria.jpg]]
## informations
**Nom **: Astaria
**Prénom **: Lucy

**Intimité**
| **Genre biologique** : Femme 
| **Genre moral** : Femme
| **Orientation sexuelle** : Lesbienne
| **Situation**: Célibataire

**Fonction**: Voleuse

## portrait

## histoire (non terminé)
Lucy est une enfant qui a perdu ses parents très tôt , ce qui fait qu'elle a du apprendre à se débrouiller seule très vite afin de survivre dans un monde trop dangereux pour une petite fille seule. Elle finira par croiser le chemin de Wymon lors de ses années formatrice peut avant sa rencontre avec Freya, le jeune prince avait déjà le cœur rebelle qu'on lui connait, et c'est lorsque Lucy essaya de lui voler sa bourse qu'il décida de s'intéresser à cette jeune fille qui avait réussi à se faufiler entre ses gardes sans se faire voir. Il lui permit donc de s'instruire, d'apprendre la diplomatie et mieux se comporter en société. Il lui donna aussi un nom pour la tirer de l'anonymat. Dû au fait qu'il l'a extirpée de sa vie horrible, Lucy qui d'ordinaire ne fait que ce qui est à son avantage ou ce qui peut lui apporter quelque chose, à un profond respect pour Wymon et sa femme Freya, elle ne dévie de ses aspirations que pour eux lorsqu'ils le lui demandent. D'ordinaire Lucy à un tempérament froid et distant, elle ne prend la peine de discuter avec quelqu'un que lorsqu'elle le/la trouve d'un intérêt certain, elle arrive à se fondre dans n'importe quel milieu social, car elle a compris que ne pas se faire remarquer est plus probant que de ne pas se faire voir lorsqu'on s'apprête à voler que ce soit des informations ou des biens. Elle a aussi un chat, Samaël, un magnifique sacré de Birmanie, qui l'accompagne partout et qui, pour une raison qui est la sienne, se tient pour la plupart du temps sur son épaule.