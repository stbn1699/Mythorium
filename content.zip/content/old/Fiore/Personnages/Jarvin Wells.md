---
draft: true
tags:
- Old
---

## image
![[PERSONNAGE_JarvinWells.jpg]]

## Informations
**Nom** : Welles 
**Prénom** : Jarvin 

**Intimité**: 
| **Genre Biologique**: Homme
| **Genre Moral**: Non binaire _(genré il/lui la plupart du temps)_ 
| **Orientation Sexuelle**: Assexuel _(mais pas aromantique)_
| **Situation**: Célibataire

**Fonction**: Couturier

## portrait
Jarvin est un homme, ni jeune ni vieux, il est toujours avec son fauteuil roulant étant donné qu'il a plus vraiment l'usage de ses jambes, fauteuil roulant qu'il a créé lui même, capable de monter les escaliers, il peut aussi y "brancher" différents modules lorsqu'il travail, tous actionnés méchaniquement et dont il peut se servir, il en a pour analyser un tissus, un pour faire des mesnures, un pour faire de la couture, avec beaucoup d'autres très utiles. Cependant, il n'est pas que couturier, comme on a pu s'en apercevoir, il est aussi très bon ingénieur et est capable de réparer / créer des machines complexes comme son fauteuil

## Histoire
Jarvin a toujours aimé la couture, le soucis étant que ce n'était pas du tout acceptable pour un homme dans son ancien royaume. Lors d'un voyage ayant pour but d'acquérir des tissus d'une grande qualité, sa famille, amis et des personnes ne voyant pas sa passion d'un bon oeil ont voulu lui donner une bonne leçon. Cependant, cela a très mal tourné ce qui l'a rendu partiellement Paraplégique, il peut bouger ses jambes mais pas beaucoup et surtout pas pour marcher. C'est a ce moment la que deux filles, jumelles, voyant la scène de loin coururent a son secours, il était au sol et incapable de se relever. Les deux filles ([Seshai](Seshai%20Yue.md) et [Shiao](Shiao%20Yue.md)) étant sur le point de partir du royaume l'aidèrent a monter dans leur carrosse, puis il partit avec elles. 

Elles prirent soin de lui au travers des royaumes qu'ils traversaient, il se trouvait a chaque arrêts des moyens de créer son fauteuil, la première version, qui lui servit au moins pour pouvoir les suivre dans les viles et villages qu'ils traversaient. Un beau jour, ils arrivèrent dans notre royaume, et a l'avis général, s'y installèrent, Jarvin pu avoir tout le temps et les ressources nécessaires a la création de la deuxième version du fauteuil, celle qu'il utilise actuellement. Et enfin, monter sa [boutique de vêtements sur mesure](Couturier.md)!