---
draft: true
tags:
- Old
---

## image
![[PERSONNAGE_SeshaiYue.jpg]]

## Informations
**Nom** : Yue 
**Prénom** : Seshai 

**Intimité**:
| **Genre Biologique**: Femme
| **Genre Moral** : Femme
| **Orientation Sexuelle**: Lesbienne
| **Situation**: Célibataire

**Fonction**: Boulangère

## portrait
Seshai est une jeune brune aux trait très fin sur le visage. Toujours joyeuse, et très mignone dans son attitude encore presque enfantine dans son genre, son rire, sourire et joie de vivre étaient extrêmement contagieux, c'est en quelques sortes le rayon de soleil du royaume. 

## Histoire
Seshai, et sa soeur [Shiao](Shiao%20Yue.md) sont soeur jumelles, lorsqu'elles étaient petites, elles adoraient jouer au magasin, Seshai aimait vendre surtout des gateaux et du pain, ce qui énervait sa mère lorsqu'elle volait ce qu'il y avais dans la cuisine pour son jeu, c'est alors qu'elle appris grâce a sa mère a faire des patisseries et du pain. Tandis que sa soeur, elle, préférait autre chose.

Elles vécurent plutôt correctement, elles n'étaient par riches mais elles n'étaient pas non plus dans le besoin. Leurs parents, essayaient des les protéger de leur royaume devenu vraiment toxique, et limite dangereux, entre les émeutes, le jugement d'autrui etc, le royaume était devenu invivable. en grandissant, les deux jumelles commençaient de plus en plus a s'en rendre compte et n'avaient qu'une envie c'était de partir. Cependant, leurs parents avaient encore plus peur de partir, peur de l'inconnu, peur de quitter ce qu'ils connaissaient. C'est alors que, lors de la mort de leurs parents a cause d'une émeute dans le magasin, les deux jumelles, surtout [Shiao](Shiao%20Yue.md) qui était beaucoup plus mature que sa soeur, prit les choses en main et fit tout ce qu'elle pu pour les faire partir.

le soir de leur départ, a l'entrée du royaume, elles virent une scène horrible, elles se précipitèrent toutes les deux vers l'homme au sol, incapable de se relever et abandonné ici par ses ravisseurs. Après une courte discussion, elles aidèrent [Jarvin](Jarvin%20Wells.md), leur nouvel ami, a monter avec elles dans le carrosse. Après plusieurs mois de recherche, les deux soeurs et l'homme arrivèrent dans notre royaume, c'est alors que, quelques mois après leurs installation et a travailler pour [sa soeur](Shiao%20Yue.md) dans l'épicerie, Seshai eut la bonne idée d'ouvrir sa boulangerie au lieu de vendre son pain dans l'épicerie.