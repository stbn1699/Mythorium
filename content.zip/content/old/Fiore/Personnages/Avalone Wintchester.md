---
draft: true
tags:
- Old
---

## Image
![[PERSONNAGE_AvaloneWintchester.jpg]]

## informations
**Nom **: Wintchester
**Prénom **: Avalone

**Intimité**
| **Genre biologique** : Femme 
| **Genre moral** : Femme
| **Orientation sexuelle** : Pansexuelle
| **Situation**: Célibataire

## portrait

Le caractère de Avalone est forgé dans le feu de la détermination et de la résilience. Elle incarne la force silencieuse, celle qui persiste face à l'adversité. Sa détermination inébranlable, forgée lors de son combat pour intégrer la formation de guerrière, se mêle à une passion ardente pour la justice. Avalone porte en elle une fierté indomptable, refusant de se laisser définir par les limites imposées par la société. Son esprit stratégique et son courage intrépide sont les fondations de sa personnalité, formant une guerrière qui ne recule devant aucun défi. Malgré son caractère résolu, elle conserve une compassion profonde, cherchant à instaurer l'équité là où elle va, créant ainsi un équilibre harmonieux entre sa force extérieure et son cœur vaillant.

## histoire

Avalone, guerrière déterminée, avait rejoint récemment le royaume. Son parcours était une lutte acharnée depuis l'enfance. Dans son royaume d'origine, elle avait défendu avec acharnement son droit à intégrer la formation de guerrière, défiant les stéréotypes de genre. 

Malgré les obstacles, elle avait brillamment réussi la formation, surpassant les attentes. Cependant, en raison de son genre, elle était privée des examens et du diplôme. L'injustice la poussa à quitter son royaume. Avalone trouva refuge dans le royaume de Fiore, accueillie directement par Freya et Wymon, espérant y être reconnue pour ses compétences plutôt que son genre. 

Devenue cheffe solitaire des armées, Avalone était déterminée à prouver que la force n'a pas de genre. Son arrivée dans le royaume marquait le début d'une nouvelle aventure où elle pourrait enfin être appréciée en tant que guerrière exceptionnelle, libérée des jugements liés à son genre.