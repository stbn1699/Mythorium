---
draft: true
tags:
- Old
---

## Image
![[PERSONNAGE_GimMov.jpg]]

## Informations
**Nom**: Mov 
**Prénom**: Gim 

**Intimité**:
| **Genre Biologique**: Homme 
| **Genre Moral**: Homme 
| **Orientation Sexuelle**: Hétéro 
| **Situation**: En couple avec [[Lagertha Osmond]]

**Fonction**: Tavernier

## portrait
Gim Mov est un grand monsieur, surement le plus imposant du royaume, il est toujours souriant et toujours très gentil et ouvert, il n'a aucun ennemi dans sa vie et dans le royaume, tout ce qui l'intéresse c'est d'être a la [[Taverne]] environ de midi a 23h pour servir et accueillir les clients, puis de dormir quelques heures avant de se réveiller préparer le petit déjeuner pour les clients des chambres s'il y en a, avant de partir se balader en [[Forêt (Extérieur)]] et aux alentours du royaume pour trouver de bons produits et surtout pour réfléchir a la recette du jour, toujours accompagné de [[Lagertha Osmond]]

## Histoire
il vient directement d'une classe pauvre de la société de son ancien royaume, il a toujours manqué de nourriture et était vraiment très maigre pendant le début de sa vie. C'est a l'adolescence, qu'il a développé une sorte d'obsession pour la nourriture. Il est devenu très bon cuisinier et a trouvé un emploi, certes très mal payé et avec de très mauvaises conditions mais cela lui a permis de manger bien plus qu'à sa guise parce qu'il fallait gouter tout les plats, ce qui ne lui déplaisait pas, bien au contraire, et cela lui permettait aussi de donner de la nourriture aux plus démunis. 

lorsqu'il a eu le pouvoir et surtout le courage de partir de son ancien royaume, il est arrivé ici et a créé sa propre taverne ou il brasse sa propre bière, ou il fait sa propre cuisine toujours plus bon d'un jour sur l'autre, il vit sa meilleure vie. Mais aussi en aidant les plus démunis, étant donné qu'il offre repas et chambres a ceux qui viendraient le voir et qui n'ont pas les moyens de payer.