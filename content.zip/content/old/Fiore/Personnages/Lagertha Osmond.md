---
draft: true
tags:
- Old
---

## image
![[PERSONNAGE_LagerthaOsmond.jpg]]

## Informations
**Nom** : Osmond 
**Prénom** : Lagertha

**Intimité**:
| **Genre Biologique**: Femme 
| **Genre Moral**: Femme 
| **Orientation Sexuelle**: Hétéro 
| **Situation**: En couple avec [[Gim Mov]]

**Fonction** : Cueilleuse / Fleuriste

## portrait
Lagertha est une brune au yeux marrons. Et au visage très doux. Elle est très gentille et souriante. Elle est à l’écoute et c’est une personne avec qui on apprécie parler en général.

## Histoire
ayant vécu depuis petite hors des limites de n'importe quel royaume, et étant seule depuis la mort de son père, elle tomba sur ce royaume lors d'une ballade cueillette.

Une fois retournée chez elle, curieuse, elle pris un petit sac avec des affaires pour venir dans le royaume voir ce qu'il en était. Elle a été directement séduite par le charme de tout ce qu'il y avait dans ce royaume, et décida alors de s'y installer.