---
draft: true
tags:
- Old
---

## image
![[PERSONNAGE_TonyaForbes.jpg]]

## Informations
**Nom** : Forbes
**Prénom** : Tonya

**Intimité**:
| **Genre Biologique**: Femme
| **Genre Moral** : Femme
| **Orientation Sexuelle**: Hétéro
| **Situation**: Célibataire

**Fonction**: Apothicaire

## portrait
Très empathique, elle toujours prête à aider les autres. Cependant, elle reste méticuleuse quant à sa manière de réfléchir.

## Histoire
Tonya Forbes est issue d'une modeste famille, ils n'avaient certes pas beaucoup d'argent mais ils sont très reconnaissants envers leurs amis, ce qui les rend particulièrement humbles auprès de tous. Reconnus pour leurs facultés de dons en médecine avec leurs connaissances sur la vie, il tiennent donc l'une des meilleurs pharmacie de leur royaume. ils ont déjà pu concevoir les meilleurs remèdes qui ont jamais existé. 

Arriva le jour ou elle repris la boutique de ses parents a l'âge de 20ans. Malheureusement, son magasin a du fermer ses portes dans son royaume d'origine, c'est alors que Tonya partit a la recherche d'un nouveau royaume d'accueil. C'est alors qu'elle trouva notre royaume, et qu'elle pu s'y installer avec la bénédiction et l'aide du roi.

Alors, une fois l'[[Apothicairerie]] fut construite, ses journée furent rythmées par l'inventaire des stocks, de la vente, et pour finir, sur la fin journée, par la préparation nouveaux produit, dans son labo située à l'arrière boutique. Elle est toujours à la quête de nouvelles choses a découvrir et à apprendre. Elle à hâte de pouvoir partir à l'aventure et en d'en savoir plus sur la médecine de son monde.