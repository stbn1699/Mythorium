---
draft: true
tags:
- Old
---

## alliances
- le royaume de [[old/Royaumes/Sylvandis]] est un très bon allié de [Fiore](Fiore.md), les relations sont bonnes et amicales entre les deux royaumes 
## aucun contact
- [[Nakasane]], seulement les deux [[Kamoto Shigeko]] et [[Kawada Shigeko]] connaissent le royaume mais il est trop loin pour avoir un quelconque contact