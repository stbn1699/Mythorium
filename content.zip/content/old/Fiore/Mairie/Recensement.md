---
draft: true
tags:
- Old
---

### [[Freya IV]]
reine du royaume avec [[Wymon III]]
### [[Gim Mov]]
Tavernier, Brasseur, Cuisinier et fondateur de la [[Taverne]] et en couple avec [[Lagertha Osmond]]
### [[Jarvin Wells]]
Couturier et fondateur du [[Couturier]]
### [[Kamoto Shigeko]]
explorateur militaire en couple avec [[Kawada Shigeko]]
### [[Kawada Shigeko]]
exploratrice militaire en couple avec [[Kamoto Shigeko]]
### [[Lagertha Osmond]]
serveuse, Cueilleuse, Fleuriste et Cuisinière, en couple avec [[Gim Mov]] et travaille a la [[Taverne]]
### [[Lamys of the Forest]]
garde royal d'origine de [[Wymon III]], qui l'a suivi quand il est parti avec [[Freya IV]]
### [[Lucy Astaria]]
Voleuse du royaume
### [[Sélène Aragorn]]
elle maitrise les éléments
### [[Seshai Yue]]
Jumelle de [[Shiao Yue]], elle est boulangère et fondatrice de la [[Boulangerie]]
### [[Shiao Yue]]
jumelle de [[Seshai Yue]], elle tient l'[[Epicerie]] du royaume
### [[Tonya Forbes]]
Apothicaire du royaume, dans l'[[Apothicairerie]]
### [[Wymon III]]
Roi du royaume avec [[Freya IV]]