---
draft: true
tags:
- Old
---

### [[Boulangerie]]
tenue par [[Seshai Yue]], elle y vends des gâteaux, du pain, et des sucreries

###  [[Couturier]]
tenu par [[Jarvin Wells]], c'est sa boutique personnelle, il y vends des tenues en tout genre, mais aussi du sur mesure

### [[Epicerie]]
tenue par [[Shiao Yue]], elle y vends absolument tout ce qui est vendable, entre ustensiles, épices, et autres

### [[Taverne]]
tenue par [[Gim Mov]] et sa femme [[Lagertha Osmond]], ils y vendent leur bière, ainsi qu'un plat du jour changé chaque jour. il est aussi possible de louer une chambre afin d'y passer la nuit

### [[Apothicairerie]]
tenue par [[Tonya Forbes]], le magasin propose des potions, médicaments, pierres et tout un tas d'autres produits en rapport avec la médecine.