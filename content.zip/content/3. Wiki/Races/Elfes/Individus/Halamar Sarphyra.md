---
draft: false
tags:
- Personnage
- Elfes
---

## Image

![[PERSONNAGE_elfe_halamarSarphyra.jpg]]

## Informations
**Nom** : Sarphyra
**Prénom** : Halamar

**origine** : [[Sylvandis]]
**Race** : [[Elfes]]

## portrait

Halamar est un homme en apparence austère, dont le visage impassible ne laisse filtrer aucune émotion. Son regard profond est souvent voilé d'un voile de mystère, révélant peu de choses sur les pensées qui se cachent derrière son regard scrutateur. Il préfère rester en retrait, observant silencieusement le monde qui l'entoure, plutôt que d'attirer l'attention sur lui-même.

La seule exception à cette réserve apparente est sa relation avec sa sœur, Neremyn. En sa présence, le masque de froideur de Halamar s'effrite, laissant entrevoir un peu de chaleur et d'affection dans ses yeux autrement impénétrables. Il est prêt à tout pour elle, et son dévouement envers sa sœur est inébranlable.

Bavard par nature, Halamar préfère laisser parler ses actions plutôt que ses mots. Son silence n'est pas le signe d'un manque d'intelligence, mais plutôt d'une réserve délibérée, une volonté de garder ses pensées et ses émotions soigneusement enfermées en lui-même. Il estime que les paroles sont souvent superflues et préfère agir de manière réfléchie et délibérée.

Protecteur envers ceux qu'il aime, Halamar veille toujours sur eux avec une vigilance sans faille. Il prend son rôle de protecteur très au sérieux et ne tolère aucune menace contre ceux qui lui sont chers. Son attitude méfiante envers les étrangers témoigne de son désir de protéger son cercle intime, et il reste sur ses gardes en présence de personnes qu'il ne connaît pas.

En somme, Halamar est un homme réservé et silencieux, mais dont la loyauté envers sa sœur et ses proches est inébranlable. Sa froideur apparente dissimule en réalité une profonde affection pour ceux qui lui sont chers, et il est prêt à tout pour les protéger des dangers qui les entourent.

## Histoire

![[Famille Sarphyra]]