---
draft: false
tags:
- Personnage
- Elfes
---

## Image

![[PERSONNAGE_elfe_neremynSarphyra.jpg]]

## Informations
**Nom** : Sarphyra
**Prénom** : Neremyn

**origine** : [[Sylvandis]]
**Race** : [[Elfes]]

**Intimité**: 
| **Genre Biologique**: Femme
| **Genre Moral**: Femme
| **Orientation Sexuelle**: Hétéro
| **Situation**: En couple avec [[Halamar Sarphyra]]

## portrait

Neremyn est une jeune femme au tempérament unique, mêlant curiosité insatiable et douceur résolue. Sa soif de découverte est aussi vaste que l'océan, et elle ne se lasse jamais d'explorer de nouveaux horizons et d'en apprendre davantage sur le monde qui l'entoure. Son visage est souvent éclairé par une lueur d'excitation lorsque ses yeux pétillants se posent sur quelque chose de nouveau et d'inconnu.

De nature timide, Neremyn préfère observer silencieusement son environnement avant de se lancer dans l'aventure. Cependant, une fois qu'elle se sent à l'aise, son énergie intérieure se dévoile, et elle devient une force de la nature, débordante de vivacité et de curiosité. Son esprit vif et alerte absorbe chaque détail avec une fascination émerveillée, cherchant à comprendre les mystères qui se cachent derrière chaque expérience.

Malgré sa vivacité d'esprit, Neremyn abhorre la violence sous toutes ses formes. Elle croit fermement en la puissance des mots pour résoudre les conflits et préfère toujours trouver un terrain d'entente plutôt que de recourir à la force. Cependant, elle n'hésitera pas à défendre ses proches si leur sécurité est menacée, déployant une détermination farouche pour les protéger des dangers qui les entourent.

Son amour pour son frère et pour ceux qu'elle considère comme sa famille est inébranlable, et elle est prête à tout pour les soutenir et les protéger. Son regard devient impitoyable lorsque quelqu'un ose s'en prendre à ceux qu'elle aime, et elle n'hésite pas à intervenir, faisant preuve d'une détermination farouche pour défendre ceux qui lui sont chers.

En somme, Neremyn incarne la douceur et la détermination, la curiosité et la compassion. Son cœur est aussi vaste que son esprit, et elle est prête à parcourir n'importe quelle distance pour découvrir les merveilles du monde et protéger ceux qu'elle aime.

## Histoire

![[Famille Sarphyra]]