---
draft: false
tags:
- Personnage
- Elfes
---

## Image

![[PERSONNAGE_elfe_zaleriaSarphyra.jpg]]

## Informations
**Nom** : Sarphyra
**Prénom** : Zaleria

**origine** : [[Sylvandis]]
**Race** : [[Elfes]]

## portrait

Zaleria est une jeune fille vive et curieuse, dotée d'une soif insatiable de découvertes héritée de sa mère, Neremyn. Ses cheveux blancs aux reflets bleus encadrent un visage délicat illuminé par des yeux d'un bleu océanique, miroirs de son esprit en éveil constant. Elle parcourt les bois et les prairies avec une grâce naturelle, toujours prête à explorer de nouveaux horizons et à dénicher des trésors cachés. Sa curiosité est tempérée par une profonde compassion pour les êtres vivants, un trait qu'elle tient de son père, Halamar, et qui la pousse à protéger les créatures de la forêt avec une détermination farouche. 

Bien que jeune, Zaleria possède une sagesse étonnante et une capacité à résoudre les conflits avec douceur et intelligence. Elle est extrêmement loyale envers sa famille et ses amis, prête à tout pour les défendre si besoin. Sa nature intrépide est équilibrée par une prudence instinctive, et elle sait quand faire preuve de retenue. Zaleria est, en somme, un mélange harmonieux de la douceur et de la détermination de ses parents, une âme aventurière avec un cœur généreux et protecteur.

## Histoire

![[Famille Sarphyra]]