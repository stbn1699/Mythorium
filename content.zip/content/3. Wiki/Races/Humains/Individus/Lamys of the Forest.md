---
draft: false
tags:
- Personnage
- Humain
---

## Image
![[PERSONNAGE_humain_LamysForest.jpg]]

## informations
**Prénom** : Lamys
**Nom** : Inconnu

**origine** : Inconnue (pour le moment)
**Race** : [[Humains]]

## portrait

Lamys est un chevalier énigmatique et solitaire, enveloppé dans une armure finement travaillée, ornée de gravures anciennes et mystérieuses. Ses yeux, d'un bleu glacial, sont les seules parties visibles de son visage, émergeant des ombres de son heaume. Imposant et silencieux, Lamys se déplace avec une détermination inébranlable, chaque mouvement trahissant une force physique impressionnante et une maîtrise martiale hors du commun. Son allure majestueuse et intimidante est tempérée par une aura de mystère, chaque mot qu'il prononce étant mesuré et porteur d'une gravité profonde.

Derrière son masque de métal, Lamys cache un esprit stratégique et une empathie profonde. Vivant reclus dans une maison isolée dans les montagnes, il semble détaché du monde, mais son cœur est guidé par un code d'honneur strict et une compassion pour les opprimés. Sa quête personnelle, dont les détails restent flous, le pousse à explorer sans relâche, chaque rencontre laissant une impression indélébile de ce chevalier mystérieux en quête de vérités cachées. Lamys est un paradoxe vivant : un guerrier redoutable avec un cœur noble, un solitaire connecté aux esprits de la forêt et aux échos de son passé.

## histoire

[[Sélène et Lamys]]
